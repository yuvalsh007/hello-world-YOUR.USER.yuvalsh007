function scrollToCV(){
    window.scrollBy(0, 610);
  }
  
  function scrollToContact(){
    window.scrollBy(0, 1220);
  }
  
  function sendEmail(){
    document.getElementById('emailIcon').style.filter= "grayscale(0%)";
  }
  