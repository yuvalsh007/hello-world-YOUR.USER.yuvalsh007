from flask import Flask, redirect, url_for, render_template
from flask import request, session
app = Flask(__name__)
import mysql.connector

app.secret_key = '9876'

from Pages.assignment10.assignment10 import assignment10
app.register_blueprint(assignment10)

@app.route('/')
def hello_world():
    return render_template('cv_yuval.html ', UserFirstName=session.get('FirstName'))


@app.route('/my_peoplecontact')
def contacts():
    return render_template('my_peoplecontact.html', UserFirstName=session.get('FirstName'))

@app.route('/assignment8')
def hobbies():
    return render_template('assignment8.html',hobbies={'camping,running,swimming'}, UserFirstName=session.get('FirstName'))

@app.route('/assignment9', methods=['GET', 'POST'])
def assignment9():
    #I'm defining a array for the total users. I've created 4 users for the assignment, with the following relevant fields.
    users=[{'firstname':'Yuval', 'email':'Yuval@gmail.com', 'age':'18', 'city':'tel aviv', 'favorite_hobby':'swimming'},
           {'firstname':'Dor', 'email':'Dor@gmail.com', 'age':'54', 'city':'beer sheva', 'favorite_hobby':'netflix'},
           {'firstname':'Shmuel', 'email':'Shmulik@gmail.com', 'age':'23', 'city':'Haifa', 'favorite_hobby':'chilling'},
           {'firstname':'Yakov', 'email':'Yaki@gmail.com', 'age':'22', 'city':'Jerusalem', 'favorite_hobby':'drinking wine'}]

    wantedUsers=[]

    if request.method == "POST":
        #This is the use of a POST form.
        Email = request.form['Email']
        UserName = request.form['UserName']
        Password = request.form['Password']
        Age = request.form['Age']
        session['FirstName'] = request.form['FirstName']

    else:
        #This is the use of a GET form.
        wantedEmail = request.args.get('email')
        if wantedEmail == '':
            wantedUsers = users
        else:
            for user in users:
                if user['email'] == wantedEmail:
                    wantedUsers.append(user)

    return render_template('Assignment9.html', users=wantedUsers,method=request.method, UserFirstName=session.get('FirstName'))

@app.route('/logout')
def logout():
    session['FirstName'] = None
    return render_template('Assignment9.html',method=request.method, UserFirstName=session.get('FirstName'))


@app.route('/assignment11/users')
def usersRetrieval():
    query="SELECT * FROM users"
    query_result = interact_db(query, 'fetch')
    relevantUsers = list(map(lambda row:row._asdict(), query_result))
    return render_template('assignment11.html', relevantUsers=relevantUsers)

@app.route('/assignment11/users/selected', defaults={'ID':1})
@app.route('/assignment11/users/selected/<int:ID>')
def oneUserRetrieval(ID = None):
    if ID:
        query = "SELECT * FROM users WHERE ID=%s LIMIT 1" % ID
        query_result = interact_db(query, 'fetch')
        if query_result:
            relevantUsers = list(map(lambda row: row._asdict(), query_result))
            return render_template('assignment11.html', relevantUsers=relevantUsers[0])
        else:
            return 'There is an error in the request. Please enter a valid ID.'


def interact_db(query, query_type: str):
    return_value = False
    connection = mysql.connector.connect(host='localhost', user='root', passwd='root', database='yassignment10')
    cursor = connection.cursor(named_tuple=True)
    cursor.execute(query)

    if query_type == 'commit':
        #Used for insert, update or delete statements.
        #Returns the number of rows affected by the query (a non-negative int)
        connection.commit()
    return_value = True

    if query_type == 'fetch':
        #Use for select statement.
        #Returns: False if the query failed, or the result of the query is successful.
        query_result= cursor.fetchall()
        return_value = query_result

    connection.close()
    cursor.close()
    return return_value



if __name__ == '__main__':
    app.run(debug=True)
